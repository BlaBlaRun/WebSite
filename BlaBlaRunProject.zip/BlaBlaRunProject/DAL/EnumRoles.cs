﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BlaBlaRunProject.DAL
{
    public enum EnumRoles
    {
        Admin,
        Supervisor,
        Normal
    }
}