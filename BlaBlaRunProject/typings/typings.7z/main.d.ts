/// <reference path="main/ambient/TypeLite/index.d.ts" />
