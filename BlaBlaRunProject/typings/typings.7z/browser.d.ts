/// <reference path="browser/ambient/TypeLite/index.d.ts" />
